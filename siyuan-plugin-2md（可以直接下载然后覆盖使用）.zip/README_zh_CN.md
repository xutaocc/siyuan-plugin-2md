[English](README.md)

# Markdown批量转换

<img src="./icon.png" width="160" height="160" alt="icon">

将思源笔记的文档批量转换为Markdown文件，支持Mkdocs、Hexo、Hugo、Vitepress、Vuepress、Obsidian等平台对应的FrontFormatter

## 核心特色

- **一键操作**：支持一键批量转换
- **属性转换**：支持属性转换为FrontFormatter
- **选择笔记**：支持自定义选择笔记本，默认选择第一个笔记本
- **文档模式**：支持把当前打开的文档作为根文档，导出该文档以及它下面的子文档
- **预设支持**：支持保存多个预设配置，方便各种平台个性化导出需求
- **输出配置**：支持自定义输出目录（可单独设置对应平台的输出目录，默认输出到用户 `[思源笔记工作空间]/temp/siyuan2md/[平台名称]` 目录）
- **Obsidian Vault 导出**：父文档导出为“同名文件夹/同名.md”，内部文档链接转换为 Obsidian 双链；本地 `assets/` 附件不限制文件类型、自动复制到 Vault，并通过路径哈希避免重名覆盖。

## FAQ

* Q1：做这个插件的缘起是什么？

  A1：对于比较懒，又不想单个文档一个个发布操作的，可用这个工具批量导出。

## 更新历史

**v1.0.0 主要更新**

- 第一个版本

更多更新记录请查看 [CHANGELOG](https://github.com/terwer/siyuan-plugin-2md/blob/main/CHANGELOG.md)

## 捐赠

如果您认可这个项目，请我喝一杯咖啡吧，这将鼓励我持续更新，并创作出更多好用的工具~

### 微信

<div>
<img src="https://static-rs-terwer.oss-cn-beijing.aliyuncs.com/donate/wechat.jpg" alt="wechat" style="width:280px;height:375px;" />
</div>

### 支付宝

<div>
<img src="https://static-rs-terwer.oss-cn-beijing.aliyuncs.com/donate/alipay.jpg" alt="alipay" style="width:280px;height:375px;" />
</div>

## 感谢

感谢 [frostime](https://github.com/siyuan-note/plugin-sample-vite-svelte) 提供的项目模板
